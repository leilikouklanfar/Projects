import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/**
 * The NflStatsExtractor program implements an application that reads data from
 * the given website, extracts the information that is required and relevant for
 * any given year in order to create a data file containing NFL game statistics
 * (for all regular season and post-season games of the given year). The data
 * file which is a CSV file is then to write the game statistics where each
 * row/line represents all the information regarding one game/match. The
 * information will be separated by a comma in the order given in the assignment
 * sheet.
 *
 * @author Leili Kouklanfar
 *
 */
public class NflStatsExtractor {
    /**
     * The main method calls a new instance of NflStatsExtractor to enable us to
     * call the non static method "run()" in order to run the program. The year of
     * the NFL statistics is either passed in through the parameter and set to that
     * given year otherwise, set to 2018 by default.
     *
     * @param arg An array of Strings containing the year of NFL statistics wanted.
     */
    public static void main(String[] arg) {
        if (arg.length == 1) {
            String yearOfGame = arg[0];
            new NflStatsExtractor().run(yearOfGame);
        } else {
            String yearOfGame = "2018";
            new NflStatsExtractor().run(yearOfGame);
        }

    }

    /**
     * This method calls other higher level methods to create and save game
     * statistics to a csv file.
     *
     * @param yearOfGame A String representing the year of NFL statistics wanted.
     */
    private void run(String yearOfGame) {
        ArrayList<GameStatPerRow> gameStat = extractData(yearOfGame);
        csvExporter(gameStat, yearOfGame);
    }

    /**
     * This method gets and returns the HTML document containing the game statistics
     * of the year that is passed in.
     *
     * @param yearOfGame gives the year of the game for data to be extracted for.
     * @return doc containing the HTML document acquired from the URL.
     */

    public Document readStatsToDoc(String yearOfGame) {

        String gameStatUrl = "https://www.pro-football-reference.com/years/" + yearOfGame + "/games.htm";
        Document doc = null;
        try {
            doc = Jsoup.connect(gameStatUrl).get();
        } catch (IOException thing) {
            System.out.println("Failed to load URL: " + gameStatUrl);
        }
        return doc;
    }

    /**
     * To retrieve text for the document element and condense the document down to
     * contain/exclude the appropriate elements using their attributes.
     *
     * @param yearOfGame gives the year of the game for data to be extracted for
     *
     */
    private ArrayList<GameStatPerRow> extractData(String yearOfGame) {
        ArrayList<GameStatPerRow> gameStats = new ArrayList<GameStatPerRow>();
        Document nflStatdocument = readStatsToDoc(yearOfGame);
        Elements statTable = nflStatdocument.select("#games tbody tr:not(.thead)");

        for (Element row : statTable) {

            String homeTeam = "";
            String homeScore = "";
            String homeYards = "";
            String homeTurnovers = "";
            String awayScore = "";
            String awayTeam = "";
            String awayYards = "";
            String gameResult = "";
            String awayTurnovers = "";
            // String dayOfWeek = "";
            String dateMMDD = "";
            String gameLocation = "";
            String weekOfGame = getTheAttributeValue(row, "week_num");
            if (!(weekOfGame.equals(""))) {

                final String dayOfWeek = getTheAttributeValue(row, "game_day_of_week");
                dateMMDD = getTheAttributeValue(row, "game_date");
                gameLocation = getTheAttributeValue(row, "game_location");
                if (gameLocation.equals("@")) {
                    homeTeam = getTheAttributeValue(row, "loser");
                    homeScore = getTheAttributeValue(row, "pts_lose");
                    homeYards = getTheAttributeValue(row, "yards_lose");
                    homeTurnovers = getTheAttributeValue(row, "to_lose");
                    awayScore = getTheAttributeValue(row, "pts_win");
                    awayTeam = getTheAttributeValue(row, "winner");
                    awayYards = getTheAttributeValue(row, "yards_win");
                    awayTurnovers = getTheAttributeValue(row, "to_win");
                } else {
                    homeTeam = getTheAttributeValue(row, "winner");
                    homeScore = getTheAttributeValue(row, "pts_win");
                    homeYards = getTheAttributeValue(row, "yards_win");
                    homeTurnovers = getTheAttributeValue(row, "to_win");
                    awayTeam = getTheAttributeValue(row, "loser");
                    awayScore = getTheAttributeValue(row, "pts_lose");
                    awayYards = getTheAttributeValue(row, "yards_lose");
                    awayTurnovers = getTheAttributeValue(row, "to_lose");
                }

                homeTeam = teamAbbreviations(homeTeam);
                awayTeam = teamAbbreviations(awayTeam);
                gameResult = gameWinnerFinder(homeScore, awayScore);
                gameStats.add(new GameStatPerRow(yearOfGame, weekOfGame, dayOfWeek, homeTeam, homeScore, awayTeam,
                        awayScore, dateMMDD, gameResult, homeYards, awayYards, homeTurnovers, awayTurnovers));
            }
        }
        return gameStats;
    }

    /**
     * This method extracts each game and writes it to a csv file with a header for
     * the first line.
     *
     * @param gameStats  an arrayList of GameStatPerRow containing all the games
     *                   from yearOfGame.
     * @param yearOfGame gives the year of the game for data to be extracted for.
     */
    public void csvExporter(ArrayList<GameStatPerRow> gameStats, String yearOfGame) {

        String fileName = yearOfGame + ".csv";
        try {
            FileOutputStream output = new FileOutputStream(fileName);
            PrintWriter csvWriter = new PrintWriter(output);
            String gameStatTableHeader = "Year,Week,Day,Home,Home Score,Away,"
                    + "Away Score,Date,Result, Home Yards,Away Yards,Home Turnovers,Away Turnovers";
            csvWriter.println(gameStatTableHeader);
            Iterator<GameStatPerRow> gameStatForEachRow = gameStats.iterator();
            while (gameStatForEachRow.hasNext()) {
                csvWriter.println(gameStatForEachRow.next());
            }
            csvWriter.close();
            output.close();

        } catch (IOException exception) {
            exception.printStackTrace();
        }
    }

    /**
     * This method searches within statRow, which is an element, to find all the
     * elements that have the attribute "data-stat" and have the specific value,
     * "value".
     *
     * @param statsRow the element which a specific value is searched for within.
     * @param value    the specific value searched for in the element
     * @return attributeValue a String containing elements which contain an
     *         attribute with the specific value.
     */
    private String getTheAttributeValue(Element statsRow, String value) {
        String attributeValue = "";
        attributeValue = statsRow.getElementsByAttributeValue("data-stat", value).text();
        return attributeValue;
    }

    /**
     * This method compares the home team and away teams scores in order to return a
     * string representing the game result. There are three possible game results
     * were 'T' is returned in the case of a tie as scores are equal, 'H' if home
     * team acquired the greater score and is the winner of the match and 'A' if
     * away team acquired the greater score and is the winner of the match
     *
     * @param homeGameScore the score of the home team
     * @param awayGameScore the score of the away team
     * @return gameResult a string representing the winner of the match or T for
     *         tie.
     */
    private String gameWinnerFinder(String homeGameScore, String awayGameScore) {

        String gameResult = "";

        int homeScore = Integer.parseInt(homeGameScore);
        int awayScore = Integer.parseInt(awayGameScore);
        if (homeScore == awayScore) {
            gameResult = "T"; // tie game
        } else if (homeScore < awayScore) {
            gameResult = "A"; // away team won
        } else {
            gameResult = "H"; // home team won
        }

        return gameResult;
    }

    /**
     * This method takes in the full name of a NFL team and returns the abbreviation
     * to the name.
     *
     * @param teamName is the full name of a NFL team
     * @return teamNameAbbreviation which is the abbreviation of the team name
     */
    private String teamAbbreviations(String teamName) {
        String teamNameAbbreviation;
        switch (teamName) {
            case "Atlanta Falcons":
                teamNameAbbreviation = "ATL";
                break;
            case "Arizona Cardinals":
                teamNameAbbreviation = "ARI";
                break;
            case "Baltimore Ravens":
                teamNameAbbreviation = "BAL";
                break;
            case "Buffalo Bills":
                teamNameAbbreviation = "BUF";
                break;
            case "Carolina Panthers":
                teamNameAbbreviation = "CAR";
                break;
            case "Chicago Bears":
                teamNameAbbreviation = "CHI";
                break;
            case "Cincinnati Bengals":
                teamNameAbbreviation = "CIN";
                break;
            case "Cleveland Browns":
                teamNameAbbreviation = "CLE";
                break;
            case "Dallas Cowboys":
                teamNameAbbreviation = "DAL";
                break;
            case "Denver Broncos":
                teamNameAbbreviation = "DEN";
                break;
            case "Detroit Lions":
                teamNameAbbreviation = "DET";
                break;
            case "Green Bay Packers":
                teamNameAbbreviation = "GB";
                break;
            case "Houston Texans":
                teamNameAbbreviation = "HOU";
                break;
            case "Indianapolis Colts":
                teamNameAbbreviation = "IND";
                break;
            case "Jacksonville Jaguars":
                teamNameAbbreviation = "JAC";
                break;
            case "Kansas City Chiefs":
                teamNameAbbreviation = "KC";
                break;
            case "Los Angeles Chargers":
                teamNameAbbreviation = "LAC";
                break;
            case "Los Angeles Rams":
                teamNameAbbreviation = "LAR";
                break;
            case "Miami Dolphins":
                teamNameAbbreviation = "MIA";
                break;
            case "Minnesota Vikings":
                teamNameAbbreviation = "MIN";
                break;
            case "New England Patriots":
                teamNameAbbreviation = "NE";
                break;
            case "New Orleans Saints":
                teamNameAbbreviation = "NO";
                break;
            case "New York Giants":
                teamNameAbbreviation = "NYG";
                break;
            case "New York Jets":
                teamNameAbbreviation = "NYJ";
                break;
            case "Oakland Raiders":
                teamNameAbbreviation = "OAK";
                break;
            case "Philadelphia Eagles":
                teamNameAbbreviation = "PHI";
                break;
            case "Pittsburgh Steelers":
                teamNameAbbreviation = "PIT";
                break;
            case "San Diego Chargers":
                teamNameAbbreviation = "SD";
                break;
            case "Seattle Seahawks":
                teamNameAbbreviation = "SEA";
                break;
            case "San Francisco 49ers":
                teamNameAbbreviation = "SF";
                break;
            case "St. Louis Rams":
                teamNameAbbreviation = "STL";
                break;
            case "Tampa Bay Buccaneers":
                teamNameAbbreviation = "TB";
                break;
            case "Tennessee Titans":
                teamNameAbbreviation = "TEN";
                break;
            case "Washington Redskins":
                teamNameAbbreviation = "WAS";
                break;

            default:
                teamNameAbbreviation = "UNK";
        }
        return teamNameAbbreviation;
    }

}