/**
 * Creates a GameStatPerRow class which holds all the information contained in
 * one row of the game statistics. By holding all the essential values for a
 * single game it then creates a string where the data is returned in the order
 * specified on the assignment sheet and where each value is separated by a
 * single comma.
 *
 * @author Leili Kouklanfar
 *
 */
public final class GameStatPerRow {

    private final String yearOfGame;
    private final String weekOfGame;
    private final String dayOfTheWeek;
    private final String homeTeam;
    private final String homeScore;
    private final String awayTeam;
    private final String awayScore;
    private final String dateMMDD;
    private final String gameResult;
    private final String homeYards;
    private final String awayYards;
    private final String homeTurnovers;
    private final String awayTurnovers;

    /**
     * This constructor creates a new game.
     *
     * @param yearOfGame    year the game was played
     * @param weekOfGame    week the game was played
     * @param dayOfTheWeek  day of week the game was played
     * @param homeTeam      the home team
     * @param homeScore     home score
     * @param awayTeam      away team
     * @param awayScore     away score
     * @param dateMMDD      date game was played with the order of month following
     *                      day
     * @param gameResult    game result/winner/tie
     * @param homeYards     home yards
     * @param awayYards     away yards
     * @param homeTurnovers home turnovers
     * @param awayTurnovers away turnovers
     */
    public GameStatPerRow(String yearOfGame, String weekOfGame, String dayOfTheWeek, String homeTeam, String homeScore,
            String awayTeam, String awayScore, String dateMMDD, String gameResult, String homeYards, String awayYards,
            String homeTurnovers, String awayTurnovers) {

        this.yearOfGame = yearOfGame;
        this.weekOfGame = weekOfGame;
        this.dayOfTheWeek = dayOfTheWeek;
        this.homeTeam = homeTeam;
        this.homeScore = homeScore;
        this.awayTeam = awayTeam;
        this.awayScore = awayScore;
        this.dateMMDD = dateMMDD;
        this.gameResult = gameResult;
        this.homeYards = homeYards;
        this.awayYards = awayYards;
        this.homeTurnovers = homeTurnovers;
        this.awayTurnovers = awayTurnovers;

    }

    /**
     * Overrides the toString function.
     *
     * @return a String of the game statistic values separated by a commas
     */
    @Override
    public String toString() {

        return yearOfGame + "," + weekOfGame + "," + dayOfTheWeek + "," + homeTeam + "," + homeScore + "," + awayTeam
                + "," + awayScore + "," + dateMMDD + "," + gameResult + "," + homeYards + "," + awayYards + ","
                + homeTurnovers + "," + awayTurnovers;
    }

    public String getYearOfGame() {
        return yearOfGame;
    }

    public String getWeekOfGame() {
        return weekOfGame;
    }

    public String getHomeTeam() {
        return homeTeam;
    }

    public String getDayOfTheWeek() {
        return dayOfTheWeek;
    }

    public String getHomeScore() {
        return homeScore;
    }

    public String getAwayTeam() {
        return awayTeam;
    }

    public String getAwayScore() {
        return awayScore;
    }

    public String getDateMMDD() {
        return dateMMDD;
    }

    public String getGameResult() {
        return gameResult;
    }

    public String getHomeYards() {
        return homeYards;
    }

    public String getAwayYards() {
        return awayYards;
    }

    public String getHomeTurnovers() {
        return homeTurnovers;
    }

    public String getAwayTurnovers() {
        return awayTurnovers;
    }

}
