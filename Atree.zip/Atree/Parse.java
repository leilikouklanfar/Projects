import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class Parse implements GlobalConstants {
    private String name;

    String getName() {
        return this.name;
    }

    // For generating unique IDs for slots and identifier.
    private int currentSlot, numberOfCL;
    // Compiling patterns has some overhead, so we only do it once.
    private Pattern slotParse, courseParse, labParse, identifierParse, prefParse, pairParse;
    // Whether we have 913 or 813 in the list already.
    private boolean is913added, is813added, slotTU18, slotTR18; // use for constraints
    // Used for building the initial structures.
    // Later cast to arrays.
    private ArrayList<Slot> slots;
    private ArrayList<Integer> fiveHundredCourses;
    private ArrayList<Tuple> notCompatibleTuple;
    private ArrayList<Tuple> pairedLecAndLabs;
    private ArrayList<PartAssignment> unWanted;
    private ArrayList<PartAssignment> pAssign;
    private MapCourseToIndex cMap;
    private MapLabToIndex lMap;
    int[][] pref;

    CoursesAndLabs coursesAndLabs;

    Parse() {
        slots = new ArrayList<>();
        notCompatibleTuple = new ArrayList<>();
        fiveHundredCourses = new ArrayList<>();
        numberOfCL = 0;

        coursesAndLabs = new CoursesAndLabs();

        String day = "([A-Z]{2})", time = "([0-9]{1,2}:[0-9]{2})", value = "([0-9]*)", separator = "[\\s]*,[\\s]*",
                courseIdent = "([A-Z]{4})", courseNumber = "([0-9]{3})", lectureNumber = "([0-9]{2})",
                assignment = "([0-9A-Z\\s]*)", whitespaces = "[\\s]*";

        // Matches and extracts lines of the form: DD, HH:MM, INT, INT
        slotParse = Pattern.compile(day + separator + time + separator + value + separator + value + whitespaces);

        // Matches and extracts lines of the form: CourseCode, CourseNum, LEC, LecNum
        courseParse = Pattern
                .compile(courseIdent + whitespaces + courseNumber + whitespaces + "LEC" + whitespaces + lectureNumber);

        // Matches and extracts lines of the form: SENG 311 (Optional: LEC 01) TUT 01
        labParse = Pattern.compile(courseIdent + whitespaces + courseNumber + "[\\s]+(?:LEC[\\s]+([0-9]{2})[\\s]+)"
                + "?(?:TUT|LAB)[\\s]+([0-9]{2})");

        // Matches and extracts lines of the form: (Assignable Name), Day, Time
        identifierParse = Pattern.compile(assignment + separator + day + separator + time);

        // Matches and extracts lines of the form: DD, HH:MM, (Assignable Name), INT
        prefParse = Pattern.compile(day + separator + time + separator + assignment + separator + value);

        // Matches and extracts lines of the form: (Assignable Name), (Assignable Name)
        pairParse = Pattern.compile(assignment + "[\\s]*,[\\s]*" + assignment);
    }

    // Parse the name field of the input.
    void getParsedName(BufferedReader buff) throws IOException {
        String line;
        while ((line = buff.readLine()) != null) {
            if (line.isEmpty())
                return;
            name = line;
        }
    }

    // Day, Start time, coursemax, coursemin
    void getParsedCourseSlots(BufferedReader buff) throws IOException {
        System.out.println("Pa:getParsedCourseSlots");
        String line;
        slotTU18 = false;
        slotTR18 = false;

        while ((line = buff.readLine()) != null) {
            Matcher split = slotParse.matcher(line);

            if (line.trim().isEmpty())
                return; // If the line is not whitespace and we can't parse it, we have a problem.

            if (split.find()) {
                // Shouldn't need input sanitation here. The regex should only match things that
                // are okay to parse.
                Slot slot = new Slot(courseConstant, currentSlot++, split.group(1), split.group(2),
                        Integer.parseInt(split.group(3)), Integer.parseInt(split.group(4)));

                // No courses can be scheduled at tuesdays 11:00-12:30.
                if (slot.day.equals("TU")
                        && (1100 <= getTimeAsInt(slot.getTime()) && getTimeAsInt(slot.getTime()) <= 1230)) {
                    System.out.println("..............." + slot.toString());
                    slot.setMax(0);
                }
                // to use later for 813/913
                if (slot.day.equals("TU") && slot.getTime().equals("18:00")) {
                    slotTU18 = true;
                }
                if (slot.day.equals("TR") && slot.getTime().equals("18:00")) {
                    slotTR18 = true;
                }

                slots.add(slot);
            } else
                throw new IOException("1pError parsing line as course slot: " + line);

        }
    }

    // Day, Start time, labmax, labmin
    void getParsedLabSlots(BufferedReader buff) throws IOException {
        System.out.println("Pa:getParsedLabSlots");
        String line;
        while ((line = buff.readLine()) != null) {
            Matcher split = slotParse.matcher(line);

            if (line.trim().isEmpty())
                return; // If the line is not whitespace and we can't parse it, we have a problem.
            if (split.find()) {
                // All lab slots must be different from all course slots.
                // Even if they have the same day and time. (And duration.)
                Slot slot = new Slot(labConstant, currentSlot++, split.group(1), split.group(2),
                        Integer.parseInt(split.group(3)), Integer.parseInt(split.group(4)));

                slots.add(slot);
            } else
                throw new IOException("2pError parsing line as a lab slot: " + line);
        }
    }

    // Course-Code Course-Number LEC Lecture-number.
    void getParsedCourses(BufferedReader buff) throws IOException {
        System.out.println("Pa:getParsedCourses");
        String line;
        while ((line = buff.readLine()) != null) {
            Matcher split = courseParse.matcher(line);

            if (line.trim().isEmpty()) {// If we hit whitespace we're done.
                return;
            }

            // If the line is not whitespace and we can't parse it, we have a problem.
            if (split.find()) {
                String id = split.group(0).trim().replaceAll("\\s+", " "); // Remove duplicate whitespace.

                numberOfCL++;

                coursesAndLabs.addCourse(new Course(numberOfCL, id));

                // Handle 813 and 913.
                if (split.group(2).equals("813")) {
                    if (!is813added)
                        is813added = true;
                } else if (split.group(2).equals("913")) {
                    if (!is913added)
                        is913added = true;
                }

                // If it's a 500 level course
                if (split.group(2).charAt(0) == '5')
                    fiveHundredCourses.add(numberOfCL);

            } else
                throw new IOException("3pError parsing line as course: " + line);
        }

    }

    // Course-Code Course-Number LEC Lecture-number (TUT|LAB) Lab-Number
    void getParsedLabs(BufferedReader buff) throws IOException {
        System.out.println("Pa:getParsedLabs");
        cMap = new MapCourseToIndex(coursesAndLabs.getSetOfCourses());
        String line;
        while ((line = buff.readLine()) != null) {
            Matcher split = labParse.matcher(line);

            if (line.trim().isEmpty())
                return; // If the line is not whitespace and we can't parse it, we have a problem.
            if (split.find()) {
                // Groups: 1: Course code 2: Course Number 3: Lecture Number (NULL=LEC 01) 4:
                // Lab/Tut Number
                String name = split.group(0).trim().replaceAll("\\s+", " "); // Remove duplicate whitespace.
                numberOfCL++;
                /*
                 * String cCode = split.group(1); String cNum = split.group(2); String lNum =
                 * split.group(3); // if null, its open to all sections String ltNum =
                 * split.group(4);
                 */
                String lNum = split.group(3);

                if (split.group(3) != null && split.group(4) != null) {
                    coursesAndLabs.addLab(new Lab(numberOfCL, name));
                    // (CourseCode CourseNumber TutorialOrLabNum LectureNum)
                } else {
                    if (lNum != null) {

                        // to track the labs that are connected/ for certain courses. If its not added
                        // to pairedLEcAndLabs, its open to all sections
                        pairedLecAndLabs.add(new Tuple(cMap.getIndexfromId(name), numberOfCL));
                    }
                }

            } else
                throw new IOException("5pError parsing line as lab: " + line);
        }

    }

    // Identifier Name, Identifier Name
    void getParsedNotCompat(BufferedReader buff) throws IOException {
        System.out.println("Pa:getParsedNotCompat");
        lMap = new MapLabToIndex(coursesAndLabs.getSetOfLabs());

        String line;
        while ((line = buff.readLine()) != null) {
            Matcher split = pairParse.matcher(line);

            if (line.trim().isEmpty())
                return; // If the line is not whitespace and we can't parse it, we have a problem.
            if (split.find()) {
                // Group1 contains first one. Group2 contains second one.
                // Add First's ID to Second's incompatible vector. And vice versa.

                boolean isCourse1 = true;
                boolean isCourse2 = true;

                String name1 = split.group(1).trim().replaceAll("\\s+", " "); // Remove duplicate whitespace.
                String name2 = split.group(2).trim().replaceAll("\\s+", " "); // Remove duplicate whitespace.

                if (name1.contains("TUT") || name1.contains("LAB")) {
                    isCourse1 = false;
                }

                if (name2.contains("TUT") || name2.contains("LAB")) {
                    isCourse1 = false;
                }

                if (isCourse1 && isCourse2) {
                    notCompatibleTuple.add(new Tuple(cMap.getIndexfromId(name1), cMap.getIndexfromId(name2)));
                } else if (!isCourse1 && !isCourse2) {
                    notCompatibleTuple.add(new Tuple(lMap.getIndexfromId(name1), lMap.getIndexfromId(name2)));
                } else if (isCourse1 && !isCourse2) {
                    notCompatibleTuple.add(new Tuple(cMap.getIndexfromId(name1), lMap.getIndexfromId(name2)));
                } else {
                    notCompatibleTuple.add(new Tuple(lMap.getIndexfromId(name1), cMap.getIndexfromId(name2)));
                }

            } else
                throw new IOException("7pCould not parse line as not-compatible: " + line);
        }

    }

    // Identifier Name, Day, Time
    void getParsedUnwanted(BufferedReader buff) throws IOException {
        System.out.println("Pa:getParsedUnwanted");
        String line;

        while ((line = buff.readLine()) != null) {
            Matcher split = identifierParse.matcher(line);

            if (line.trim().isEmpty())
                return; // If the line is not whitespace and we can't parse it, we have a problem.
            if (split.find()) {
                // Group1 contains assignable name. Group2 contains day. Group 3 contains time.

                String name = split.group(1).trim().replaceAll("\\s+", " "); // Remove duplicate whitespace.
                String day = split.group(2).trim().replaceAll("\\s+", " "); // Remove duplicate whitespace.
                String time = split.group(3).trim().replaceAll("\\s+", " ");
                unWanted.add(new PartAssignment(name, day, time));

            } else
                throw new IOException("10pError parsing line as unwanted: " + line);
        }
    }

    // Day, Time, Identifier Name, Preference Value
    void getParsedPrefs(BufferedReader buff) throws IOException {
        System.out.println("Pa:getParsedPrefs:");
        String line;

        pref = new int[numberOfCL][slots.size()];
        /*
         * for (int i = 0; i < pref.length; i++) { // this equals to the row in our
         * matrix. for (int j = 0; j < pref[i].length; j++) { // this equals to the
         * column in each row. System.out.print(pref[i][j] + " "); }
         * System.out.println(); // change line on console as row comes to end in the
         * matrix. }
         */

        while ((line = buff.readLine()) != null) {
            // System.out.println("Pa:getParsedPrefs:line" + line);
            Matcher split = prefParse.matcher(line);
            int identifierType;
            int indexCL;

            if (line.trim().isEmpty()) {
                System.out.println("prob in parsed pref");
                return; // If the line is not whitespace and we can't parse it, we have a problem.
            }
            if (split.find()) {
                // Group1 contains day, 2 contains time, 3 contains assignable, 4 contains
                // value.

                String name = split.group(3).trim().replaceAll(" +", " "); // Remove duplicate whitespace.

                if (name.contains("TUT") || name.contains("LAB")) {
                    identifierType = labConstant;
                    indexCL = lMap.getIndexfromId(name);
                } else {
                    identifierType = courseConstant; // course
                    indexCL = cMap.getIndexfromId(name);
                }

                int slotIndex = -1;
                for (Slot slot : slots) {

                    if (slot.day.equals(split.group(1)) && slot.time.equals(split.group(2))
                            && (identifierType != slot.getSlotType()))
                        slotIndex = slot.index;
                }

                if (slotIndex != -1) {
                    pref[indexCL][slotIndex] = Integer.parseInt(split.group(4));
                } else {
                    System.out.println(
                            "11ppreference not found" + "Could not add pair " + line + " because slot does not exist");
                }

            } else
                throw new IOException("13pError parsing line as preference: " + line);
        }
    }

    // Identifier Name, Identifier Name
    void getParsedPair(BufferedReader buff) throws IOException {
        System.out.println("Pa:getParsedPartAssign");

        String line;
        while ((line = buff.readLine()) != null) {
            Matcher split = pairParse.matcher(line);

            if (line.trim().isEmpty())
                return; // If the line is not whitespace and we can't parse it, we have a problem.
            if (split.find()) {
                // Group1 contains an assignable. Group 2 contains an assignable.
                // Add First's ID to Second's incompatible vector. And vice versa.
                boolean isCourse1 = true;
                boolean isCourse2 = true;

                String name1 = split.group(1).trim().replaceAll("\\s+", " "); // Remove duplicate whitespace.
                String name2 = split.group(2).trim().replaceAll("\\s+", " "); // Remove duplicate whitespace.

                if (name1.contains("TUT") || name1.contains("LAB")) {
                    isCourse1 = false;
                }

                if (name2.contains("TUT") || name2.contains("LAB")) {
                    isCourse1 = false;
                }

                if (isCourse1 && isCourse2) {
                    pairedLecAndLabs.add(new Tuple(cMap.getIndexfromId(name1), cMap.getIndexfromId(name2)));
                } else if (!isCourse1 && !isCourse2) {
                    pairedLecAndLabs.add(new Tuple(lMap.getIndexfromId(name1), lMap.getIndexfromId(name2)));
                } else if (isCourse1 && !isCourse2) {
                    pairedLecAndLabs.add(new Tuple(cMap.getIndexfromId(name1), lMap.getIndexfromId(name2)));
                } else {
                    pairedLecAndLabs.add(new Tuple(lMap.getIndexfromId(name1), cMap.getIndexfromId(name2)));
                }

            } else
                throw new IOException("15pError parsing line as pair: " + line);
        }
    }

    // ModuleComponent Name, Day, Time
    void getParsedPartAssign(BufferedReader buff) throws IOException {
        System.out.println("Pa:getParsedPartAssign");
        String line;

        while ((line = buff.readLine()) != null) {
            Matcher split = identifierParse.matcher(line);

            if (line.trim().isEmpty())
                return; // If the line is not whitespace and we can't parse it, we have a problem.
            if (split.find()) {
                // Group1 contains assignable name. Group2 contains day. Group 3 contains time.

                String name = split.group(1).trim().replaceAll("\\s+", " "); // Remove duplicate whitespace.
                String day = split.group(2).trim().replaceAll("\\s+", " "); // Remove duplicate whitespace.
                String time = split.group(3).trim().replaceAll("\\s+", " ");
                pAssign.add(new PartAssignment(name, day, time));

            } else
                throw new IOException("10pError parsing line as unwanted: " + line);
        }
    }

    int[][] getNotCompatible() {
        System.out.println("Pa:getParsedPrefs:");
        int[][] notCompatible = new int[numberOfCL][numberOfCL];

        for (int i = 0; i < pairedLecAndLabs.size(); i++) {

            notCompatible[pairedLecAndLabs.get(i).getFirst()][pairedLecAndLabs.get(i).getSecond()] = 1;
            notCompatible[pairedLecAndLabs.get(i).getSecond()][pairedLecAndLabs.get(i).getFirst()] = 1;

        }
        return notCompatible;
    }

    int[][] getPairs() {
        System.out.println("Pa:getParsedPrefs:");
        int[][] pair = new int[numberOfCL][numberOfCL];

        for (int i = 0; i < pairedLecAndLabs.size(); i++) {

            pair[pairedLecAndLabs.get(i).getFirst()][pairedLecAndLabs.get(i).getSecond()] = 1;
            pair[pairedLecAndLabs.get(i).getSecond()][pairedLecAndLabs.get(i).getFirst()] = 1;

        }
        return pair;
    }

    // Fill the overlaps array of prob.
    boolean[][] checkOverlap() {
        System.out.println("Pa:checkOverlap");
        // Some hard-coded overlapping slot times. Keys are lab times. Values are course
        // times.
        // These are only valid for TU/TH, of course.
        boolean[][] overlaps = new boolean[slots.size()][slots.size()];
        HashMap<String, String> overlapPairs = new HashMap<>();
        overlapPairs.put("9:30", "10:00");
        overlapPairs.put("11:00", "12:00");
        overlapPairs.put("12:30", "13:00");
        overlapPairs.put("14:30", "15:00");
        overlapPairs.put("15:30", "16:00");
        overlapPairs.put("17:00", "18:00");
        overlapPairs.put("18:30", "19:00");

        // Figure out which slots overlaps.
        // This is really, really gross and expensive. (And could be optimized.)
        // But it is only run once so it's not a huge target for optimization.
        // And it is not well defined in the spec so I'd rather not waste effort on it.
        for (Slot slot1 : slots) {
            for (Slot slot2 : slots) {
                if ((slot1.day.equals(slot2.day) || ((slot1.getMax() == 0 || slot2.getMax() == 0)
                        && slot1.day.equals("MO") && slot2.day.equals("FR")))
                        && (slot1.time.equals(slot2.time)
                                || (slot1.day.equals("TU") && ((overlapPairs.containsKey(slot1.time)
                                        && overlapPairs.get(slot1.time).equals(slot2.time))
                                        || slot1.time.substring(0, slot1.time.indexOf(':'))
                                                .equals(slot2.time.substring(0, slot2.time.indexOf(':'))))))) {
                    overlaps[slot1.index][slot2.index] = true;
                    overlaps[slot2.index][slot1.index] = true;
                }
            }
        }
        return overlaps;

    }

    /*
     * // Does some post-processing on the problem. void checkEdgeCases(Problem
     * prob) { System.out.println("Pa:checkEdgeCases"); node.setFullSolution(true);
     * // Add 813 and 913 -> TU 18:00 - 19:00 to partassign int index =
     * prob.getSlotIndex("TU", "18:00", true);
     *
     * if (cpsc813index != -1) { node.slotOf[cpsc813index] = index; //
     * node.slotOf.replace(cpsc813index, index); for (int i : notCompatible813)
     * prob.mComp[cpsc813index].incompatible.add(i); } if (cpsc913index != -1) {
     * node.slotOf[cpsc913index] = index; // node.slotOf.replace(cpsc913index,
     * index); for (int i : notCompatible913)
     * prob.mComp[cpsc913index].incompatible.add(i); }
     *
     * // All 500 level courses should be incompatible with one another for (int i :
     * fiveHundredCourses) { for (int j : fiveHundredCourses) if (j != i)
     * prob.mComp[i].incompatible.add(j); }
     *
     * // Check if we have a full solution for (int i : node.slotOf) if (i == -1) {
     * node.setFullSolution(false); break; } }
     */

    int getTimeAsInt(String tString) {

        String[] timeInParts = tString.split(":");
        return (Integer.parseInt(timeInParts[0]) * 100) + Integer.parseInt(timeInParts[1]);
    }

    ArrayList<Slot> getSlots() {
        return slots;
    }

    ArrayList<Integer> getFiveHundredCourses() {
        return fiveHundredCourses;
    }

    ArrayList<Tuple> getNotCompatibleTuple() {
        return notCompatibleTuple;
    }
/*
    ArrayList<Tuple> getPairedLecAndLabs() {
        return pairedLecAndLabs;
    }
*/
    ArrayList<PartAssignment> getUnWanted() {
        return unWanted;
    }

    ArrayList<PartAssignment> getPAssign() {
        return pAssign;
    }

    int[][] getPref() {
        return pref;
    }
}
