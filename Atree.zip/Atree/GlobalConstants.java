
public interface GlobalConstants {
    public int courseConstant = 0; // 0 for courses, 1 for labs
    public int labConstant = 1;

}
