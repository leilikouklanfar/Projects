// used for part
public class PartAssignment {

    final private String name;

    final private String day;

    final private String time;
    final int timeAsInt; // 10-24 has form HHMM for time or HMM for time 1-9

    PartAssignment(String name, String day, String time) {
        this.name = name;
        this.day = day;
        this.time = time;
        String[] timeInParts = time.split(":");
        timeAsInt = (Integer.parseInt(timeInParts[0]) * 100) + Integer.parseInt(timeInParts[1]); // -034556
    }
    // getters and setters.

    String getname() {
        return name;
    }

    String getDay() {
        return day;
    }

    String getTime() {
        return time;
    }

    int getTimeAsInt() {
        return timeAsInt;
    }
}
