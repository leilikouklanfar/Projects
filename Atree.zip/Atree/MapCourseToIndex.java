import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MapCourseToIndex {
    private Map<String, Integer> labMap;

    public MapCourseToIndex(ArrayList<Course> courses) {
        labMap = new HashMap<>();

        for (int i = 0; i < courses.size(); i++) {
            String identifier = courses.get(i).getName();
            System.out.println("IN MapToIndex: fix string syntax: " + identifier);

            labMap.put(identifier, courses.get(i).indexInCL);
        }
    }

    int getIndexfromId(String id) {
        System.out.println("IN MapToIndex getIndexfromId");
        return labMap.get(id);
    }
}
