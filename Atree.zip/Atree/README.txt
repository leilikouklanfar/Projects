Compilation and execution instructions:

Make sure you are in the /src folder and all test files are in in this folder before doing the following.

To compile:

.	javac *.java


To run:

.	java Main <wMinFilled> <wPref> <wSecDiff> <wPair> <pen_coursemin> <pen_labsmin> <pen_section> <pen_notpaired> <input file name>

	Example:
	
	.	java Main 1 0 0 0 100 100 10 0 minnumber.txt