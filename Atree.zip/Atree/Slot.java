/*
 * What a single slot consists of
 *
 * slotType - type of slot(0/1 for course/lab)
 * index -
 * max - max number of courses or labs permitted for that slot
 * min - min number of courses or labs permitted for that slot
 * time - time of lecture
 *
 *
 */

public class Slot {
    final int index;
    final String day;
    // "MO" or "TU" for courses
    // "MO", "TU", and "FR" for Labs
    final String time;
    private int slotType; // 0 for courses, 1 for labs
    private int max; // max number of courses or labs permitted for that slot
    private int min; // min number of courses or labs permitted for that slot

    Slot(int slotType, int index, String day, String time, int max, int min) {
        this.slotType = slotType;
        this.index = index;
        this.day = day;
        this.time = time;
        this.max = max;
        this.min = min;
    }

    // getters and setters.
    int getIndex() {
        return index;
    }

    String getTime() {
        return time;
    }

    String getDay() {
        return day;
    }

    int getSlotType() {
        return slotType;
    }

    int getMax() {
        return max;
    }

    int getMin() {
        return min;
    }

    void setMax(int newMax) {
        this.max = newMax;
    }

    void setMin(int newMin) {
        this.min = newMin;
    }

    // Nice for debugging.
    @Override
    public String toString() {
        String type = "course";
        if (slotType == 1) {
            type = "lab";
        }

        return "Index: " + index + ", Day: " + day + ", Time: " + time + ", " + type + "Max: " + max + ", " + type
                + "Min: " + min;
    }
}