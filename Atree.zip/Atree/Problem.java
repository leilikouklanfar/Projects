// can be used as our current problem as each node has a problem, the partial assignments
public class Problem {

    // The partial assignment for this problem. Serves as our starting state.
    final Slot[] slots;
    final CoursesAndLabs cL;

    // We have an unchanging number of mComp and slots. Must be initialized
    // with these.
    Problem(Slot[] slots, CoursesAndLabs cL) {
        this.slots = slots;
        this.cL = cL;
    }

    Slot[] getAvailableSlots() {
        return slots;
    }

    CoursesAndLabs getAvailableCL() {
        return cL;
    }

}
