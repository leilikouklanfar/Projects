import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MapLabToIndex {
    private Map<String, Integer> labMap;

    public MapLabToIndex(ArrayList<Lab> labs) {
        labMap = new HashMap<>();

        for (int i = 0; i < labs.size(); i++) {
            String identifier = labs.get(i).getName();

            System.out.println("IN MapLabToIndex: fix string syntax: " + identifier);

            labMap.put(identifier, labs.get(i).indexInCL);
        }
    }

    int getIndexfromId(String id) {
        System.out.println("IN MapToIndex getIndexfromId");
        return labMap.get(id);
    }
}
