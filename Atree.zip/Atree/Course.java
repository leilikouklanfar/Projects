public class Course {
    final int indexInCL;
    final String name;
    boolean isEvening;

    public Course(int indexInCL, String name) {
        this.indexInCL = indexInCL;
        this.name = name;
    }

    int getIndexInCL() {
        return indexInCL;
    }

    String getName() {
        return name;
    }

    boolean getIsEvening() {
        return isEvening;
    }

    boolean setIsEvening() {
        return this.isEvening;
    }

}

/*
 * public class Course { final int indexInCL; final String deptProgram; final
 * String courseNum; final String sectionNum; boolean isEvening;
 *
 * public Course(int indexInCL, String deptProgram, String courseNum, String
 * sectionNum) { this.indexInCL = indexInCL; this.deptProgram = deptProgram;
 * this.courseNum = courseNum; this.sectionNum = sectionNum; }
 *
 * int getIndexInCL() { return indexInCL; }
 *
 * String getDeptProgram() { return deptProgram; }
 *
 * String getCourseNum() { return courseNum; }
 *
 * String getSectionNum() { return sectionNum; }
 *
 * boolean getIsEvening() { return isEvening; }
 *
 * boolean setIsEvening() { return this.isEvening; }
 *
 * }
 */