
public class Tuple {
    private int first;
    private int second;

    Tuple(int first, int second) {
        this.first = first;
        this.second = second;
    }

    int getFirst() {
        return first;
    }

    int getSecond() {
        return second;
    }

}
