
public class SearchModel {
//do eval, div, best solution all in here
}
