public class Lab {

    final int indexInCL;
    final String name;
    boolean isEvening;

    // Labs of syntax (CourseCode CourseNumber TutorialOrLabNum LectureNum)
    public Lab(int indexInCL, String name) {
        this.indexInCL = indexInCL;
        this.name = name;
        this.isEvening = false;
    }

    int getIndexInCL() {
        return indexInCL;
    }

    String getName() {
        return name;
    }

    boolean getIsEvening() {
        return isEvening;
    }

    boolean setIsEvening() {
        return this.isEvening;
    }

}
/*
 * public class Lab {
 *
 * final int indexInCL; final String deptProgram; final String courseNum; final
 * String sectionNum; final String labOrTutNum; boolean isEvening;
 *
 * // Labs of syntax (CourseCode CourseNumber TutorialOrLabNum LectureNum)
 * public Lab(int indexInCL, String deptProgram, String courseNum, String
 * sectionNum, String labOrTutNum) { this.indexInCL = indexInCL;
 * this.deptProgram = deptProgram; this.courseNum = courseNum; this.sectionNum =
 * sectionNum; this.labOrTutNum = labOrTutNum; this.isEvening = false; }
 *
 * int getIndexInCL() { return indexInCL; }
 *
 * String getDeptProgram() { return deptProgram; }
 *
 * String getCourseNum() { return courseNum; }
 *
 * String getSectionNum() { return sectionNum; }
 *
 * String getLabOrTutNum() { return labOrTutNum; }
 *
 * boolean getIsEvening() { return isEvening; }
 *
 * boolean setIsEvening() { return this.isEvening; }
 *
 * }
 */