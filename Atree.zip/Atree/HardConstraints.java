
public class HardConstraints {

}
