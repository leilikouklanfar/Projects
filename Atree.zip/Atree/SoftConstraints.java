
public class SoftConstraints {

}
