
public class Driver {

    public static void main(String[] args) {
        // start program
        AtreeScheduler makeSchedule = new AtreeScheduler(args);
    }
}
