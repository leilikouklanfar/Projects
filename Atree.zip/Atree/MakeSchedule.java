import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class MakeSchedule {

    /**
     * The main method calls a new instance of CCDatabaseRunTime to enable us to
     * call the non static method "run()" in order to run the program. The name of
     * the text file is passed in through the parameter.
     *
     * @param args An array of Strings containing the text file name.
     */
    public static void main(String[] args) {

        private static void printFormat() {
            System.out.println(
                    "Usage: java project.Driver pen_coursemin: <pen_coursemin> pen_labsmin: <pen_labsmin> pen_notpaired: <pen_notpaired> pen_section: <pen_section>\n"
                            + "wMinFilled: <wMinFilled> wPref: <wPref> wPair: <wPair> wSecDiff: <wSecDiff> <input file name>");
        }

        public static void main(String[] args) {
            // Penalties for not meeting minimum number of courses.
            int pen_coursemin = 0;
            int pen_labsmin = 0;
            int pen_section = 0;
            int pen_notpaired = 0;

            // Weightings of different parts of the Eval function.
            double wMinFilled = 0.0;
            double wPref = 0.0;
            double wPair = 0.0;
            double wSecDiff = 0.0;
            String fileName;

            Parse parse = new Parse();
            Problem prob = null;

            // Parse command line arguments.
            // Error handling is done incredibly lazy here. Deal w/ it.
            if (args.length < 1) {
                printFormat();
                System.exit(1);
            }
            try {
                for (int i = 0; i < args.length - 1; i += 2) {
                    if (args[i].equals("pen_coursemin:"))
                        pen_coursemin = Integer.parseInt(args[(i + 1)]);
                    else if (args[i].equals("pen_labsmin:"))
                        pen_labsmin = Integer.parseInt(args[(i + 1)]);
                    else if (args[i].equals("pen_notpaired:"))
                        pen_notpaired = Integer.parseInt(args[(i + 1)]);
                    else if (args[i].equals("pen_section:"))
                        pen_section = Integer.parseInt(args[(i + 1)]);
                    else if (args[i].equals("wMinFilled:"))
                        wMinFilled = Double.parseDouble(args[(i + 1)]);
                    else if (args[i].equals("wPref:"))
                        wPref = Double.parseDouble(args[(i + 1)]);
                    else if (args[i].equals("wPair:"))
                        wPair = Double.parseDouble(args[(i + 1)]);
                    else if (args[i].equals("wSecDiff:"))
                        wSecDiff = Double.parseDouble(args[(i + 1)]);
                    else {
                        printFormat();
                        System.exit(1);
                    }
                }
            } catch (Exception ex) {
                printFormat();
                System.exit(1);
            }

            // Our filename must always be the last argument.
            fileName = args[args.length - 1];

            // Parse the input file.
            try {
                // prob = parse.parseInput(fileName);
                BufferedReader buff = new BufferedReader(new FileReader(fileName));
                String line;
                while ((line = buff.readLine()) != null) {
                    line = line.trim();
                    // Look for lines that match sections of the input.
                    // For each of these lines, call the appropriate subroutine.
                    if (line.equals("Name:"))
                        parse.getParsedName(buff);
                    else if (line.equals("Course slots:"))
                        parse.getParsedCourseSlots(buff);
                    else if (line.equals("Lab slots:"))
                        parse.getParsedLabSlots(buff);
                    else if (line.equals("Courses:"))
                        parse.getParsedCourses(buff);
                    else if (line.equals("Labs:"))
                        parse.getParsedLabs(buff);
                    else if (line.equals("Not compatible:"))
                        parse.getParsedNotCompat(buff);
                    else if (line.equals("Unwanted:"))
                        parse.getParsedUnwanted(buff);
                    else if (line.equals("Preferences:"))
                        parse.getParsedPrefs(buff);
                    else if (line.equals("Pair:"))
                        parse.getParsedPair(buff);
                    else if (line.equals("Partial assignments:"))
                        parse.getParsedPartAssign(buff);
                    else if (!line.isEmpty())
                        throw new IllegalStateException("Could not parse line: " + line);
                }

                // Return a new problem with all this information.
                prob = new Problem(parse.getSlots().toArray(new Slot[0]),
                        parse.getIdentifiers().toArray(new Identifier[0]));
                prob.setName(parse.getName());
                prob.setPref(parse.getPref());
                parse.getNode().setProb(prob);
                prob.setStartNode(parse.getNode());
                parse.checkOverlap(prob);
                parse.checkEdgeCases(prob);
                // Initialize its value.
                parse.getNode().setEval(prob.compute.eval(parse.getNode()));
                // Put our parsed penalties and eval weights in here.
                prob.compute.setPen_coursemin(pen_coursemin);
                prob.compute.setPen_labmin(pen_labsmin);
                prob.compute.setPen_notpaired(pen_notpaired);
                prob.compute.setPen_section(pen_section);
                prob.compute.setwMinFilled(wMinFilled);
                prob.compute.setwPair(wPair);
                prob.compute.setwPref(wPref);
                prob.compute.setwSecDiff(wSecDiff);
            } catch (IOException ex) {
                System.out.println(ex.toString());
                System.exit(1);
            } catch (IllegalStateException ex) {
                System.out.print("Error parsing file: " + ex.getMessage());
                System.exit(1);
            }

            // Do some initial checking on our partAssign.
            if (!prob.compute.constr(prob.getStartNode())) {
                System.out.println("Partassign invalid.\n");
                System.exit(1);
            }

            // Create a search control for our problem.
            Search branchBound = new Search(prob);

            // Run the search control to get our final solution.
            Node solution = branchBound.solve();

            // Show our solution.
            if (solution == null)
                System.out.println("No solutions were found.");
            else {
                System.out.println(solution);
            }
        }
    }
