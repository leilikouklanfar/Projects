import java.util.ArrayList;

// set of courses and labs
public class CoursesAndLabs {

    private ArrayList<Lab> setOfLabs;
    private ArrayList<Course> setOfCourses;

    public CoursesAndLabs() {
        setOfLabs = new ArrayList<>();
        setOfCourses = new ArrayList<>();
    }

    // getters and setters.
    void addCourse(Course course) {
        setOfCourses.add(course);

    }

    void removeCourse(Course course) {
        setOfCourses.remove(course);
    }

    /*
     *
     * int courseIndex(String name) {
     *
     * for (int i = 0; i < setOfCourses.size(); i++) { Course currentCourse =
     * setOfCourses.get(i); if (currentCourse.getName().equals(name)) { return
     * currentCourse.getIndexInCL(); } } return -1; }
     */

    void addLab(Lab lab) {
        setOfLabs.add(lab);
    }

    void removeLab(Lab lab) {
        setOfLabs.remove(lab);
    }

//dont need
    void containLab(Lab lab) {
        setOfLabs.contains(lab);
    }

    ArrayList<Lab> getSetOfLabs() {
        return setOfLabs;
    }

    ArrayList<Course> getSetOfCourses() {
        return setOfCourses;
    }

    int getNumCL() {
        return getNumLabs() + getNumCourses();

    }

    private int getNumCourses() {
        // TODO Auto-generated method stub
        return setOfCourses.size();
    }

    private int getNumLabs() {
        // TODO Auto-generated method stub
        return setOfLabs.size();
    }
}
