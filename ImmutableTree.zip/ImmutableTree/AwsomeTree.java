import java.util.ArrayList;
import java.util.NoSuchElementException;

/**
 * NAME: LEILI KOUKLANFAR
 *
 * COURSE: COMP 2631
 *
 * INSTRUCTOR: JASON HEARD
 *
 * ASSIGNMENT: #3
 *
 * This program creates an AwsomeTree class which is an immutable sorted set
 * that holds string keys. By creating a Node class which holds all the
 * information required for a tree node, the following program is able to add,
 * remove, output an array of the tree in alphabetical order and can search for
 * a given key in the tree. Each node has an index (starting from 0 to tree size
 * -1) which has the same value that a Node would be given if an in order
 * traversal where to be done for the binary tree(AwsomeTree). The program
 * provides functions to calculate the index of a node or find the key at a
 * given node.
 *
 * @author leilikouklanfar
 *
 */

public class AwsomeTree implements ImmutableSortedSet {

    private final Node root;

    /**
     * Initializes the root of the tree.
     *
     * @param tree - the root Node that root is to be initialized to.
     */
    public AwsomeTree(Node tree) {
        this.root = tree;
    }

    @Override
    public AwsomeTree add(String key) {
        if (key == null) {
            key = "null";
        }
        if (contains(key)) {
            return this;
        }
        return new AwsomeTree(add(this.root, key));
    }

    /**
     * Creates a new Node and inserts the node in the tree "root". The keys
     * placement is based upon the keys alphabetical order with 'null' being the
     * first letter of the alphabet, 'a' being the second,..., 'z' being the last.
     *
     * @param root - the root Node of the tree
     *
     * @param key  - a String that is the key that is to be inserted into the tree
     *
     * @returns Node root - root with the key added in to the node
     */
    private static Node add(Node root, String key) {

        if (root == null) {
            return new Node(key, null, null);
        }
        if (compareString(root.getKey(), key) == 1 || key == "null") {
            return root.changeLeft(add(root.getLeftChild(), key));
        } else {
            return root.changeRight(add(root.getRightChild(), key));
        }
    }

    @Override
    public ImmutableSortedSet remove(String key) {
        if (key == null) {
            key = "null";
        }
        if (!contains(key)) {
            return this;
        }
        return new AwsomeTree(remove(this.root, key));
    }

    /**
     * Finds the Node with the key value of "key" and computes the values of the
     * Nodes left and right subtrees so the children of the Node are not lost
     * following the removal of the given Node.
     *
     * @param root - the root Node of the tree
     *
     * @param key  - A String that is the key that is to be inserted into the tree
     *
     * @return Node root - root with the given key removed
     */
    private static Node remove(Node root, String key) {

        if (compareString(root.getKey(), key) == 0) {

            if (root.getLeftChild() == null && root.getRightChild() == null) {

                return null;

            } else if (root.getLeftChild() == null) {

                return root.getRightChild();

            } else if (root.getRightChild() == null) {

                return root.getLeftChild();

            } else {
                return twoChilderen(root.getLeftChild(), root.getRightChild());
            }

        }

        if (compareString(root.getKey(), key) == 1) {
            return root.changeLeft(remove(root.getLeftChild(), key));
        } else {
            return root.changeRight(remove(root.getRightChild(), key));
        }

    }

    /**
     * Takes in two subtrees and makes rightSubtree the right subtree of the in
     * order predecessor of leftSubtree.
     *
     * @param leftSubtree  - a non-null subtree were all keys alphabetically before
     *                     the keys in rightSubtrees.
     *
     * @param rightSubtree - a non-null subtree were all keys alphabetically after
     *                     the keys in leftSubtrees
     *
     * @return a Node which is the leftSubtree with rightSubtree as its in order
     *         predecessor.
     */
    private static Node twoChilderen(Node leftSubtree, Node rightSubtree) {

        if (leftSubtree.getRightChild() != null) {
            return leftSubtree.changeRight(twoChilderen(leftSubtree.getRightChild(), rightSubtree));
        } else {
            return leftSubtree.changeRight(rightSubtree);
        }
    }

    @Override
    public String getAtIndex(int index) throws NoSuchElementException {
        if (root == null || index >= root.getSize()) {
            throw new NoSuchElementException();
        }
        String keyAtIndex = getKey(root, index);
        if (keyAtIndex == "null") {
            return null;
        }
        return keyAtIndex;

    }

    /**
     * Searches through the root Node in order to find the value of the key that is
     * at that given index.
     *
     * @param root  - the root of the tree
     * @param index - the index in which its key is searched for.
     * @return A String representing the value of the key at the given index.
     * @throws NoSuchElementException - if the Node with the key, 'key' is not
     *                                found.
     */
    private String getKey(Node root, int index) throws NoSuchElementException {
        if (root == null) {
            throw new NoSuchElementException();
        }

        if (getIndex(root.getKey()) == index) {

            return root.getKey();

        } else if (getIndex(root.getKey()) > index) {

            return getKey(root.getLeftChild(), index);

        } else {

            return getKey(root.getRightChild(), index);
        }
    }

    @Override
    public int getIndex(String key) throws NoSuchElementException {
        if (key == null) {
            key = "null";
        }
        if (!contains(key)) {
            throw new NoSuchElementException();
        } else {

            if (root.getLeftChild() == null && root.getRightChild() == null) {
                return 0;
            } else if (root.getLeftChild() == null) {
                return getIndex(root, key, 0);
            } else if (root.getRightChild() == null) {
                return getIndex(root, key, root.getLeftChild().getSize() + 1);
            } else if (root.getLeftChild().getSize() == root.getRightChild().getSize()) {
                return getIndex(root, key, root.getLeftChild().getSize());
            } else {
                return getIndex(root, key, root.getLeftChild().getSize() + 1);
            }

        }

    }

    /**
     * Searches through the Node root to find the Node with the key, 'key'.
     *
     * @param root        - the root Node of the tree
     * @param key         - a String that is the key which its index is being
     *                    searched for.
     * @param indexOfRoot - the index of the root.
     * @return An integer representing the index of at which the the Node with the
     *         key, 'key' is located.
     */
    private static int getIndex(Node root, String key, int indexOfRoot) {
        if (key == null) {
            key = "null";
        }
        if (compareString(root.getKey(), key) == 0) {
            return indexOfRoot;

        }
        if (compareString(root.getKey(), key) == 1) {

            if (root.getLeftChild().getSize() > root.getRightChild().getSize()) {

                return getIndex(root.getLeftChild(), key, indexOfRoot - 1);

            } else {

                return getIndex(root.getLeftChild(), key, root.getLeftChild().getSize());

            }

        } else {

            int sizeOfLeftSub = 0;
            root = root.getRightChild();
            if (root.getLeftChild() != null) {
                sizeOfLeftSub = indexOfRoot + (root.getLeftChild().getSize()) + 1;
            }

            return getIndex(root, key, indexOfRoot + sizeOfLeftSub + 1);

        }
    }

    @Override
    public boolean contains(String key) {
        if (key == null) {
            key = "null";
        }
        return contains(this.root, key);
    }

    /**
     * Searches the right and left subtree of root for Node with the key "key", the
     * function returns < false > is the Node with the given key is not found and <
     * true > if it is.
     *
     * @param root - the root Node of the tree.
     *
     * @param key  - a String that is the key being searched for.
     *
     * @return boolean - representing if the key was or was not found.
     *
     */
    private static boolean contains(Node root, String key) {

        if (root == null) {
            if (key == null) {
                return true;
            } else {
                return false;
            }
        }

        if (root.getKey().equals(key)) {
            return true;
        }

        return contains(root.getLeftChild(), key) || contains(root.getRightChild(), key);
    }

    @Override
    public int size() {
        if (root == null) {
            return 0;
        }
        return root.getSize();
    }

    @Override
    public String[] keys() {
        ArrayList<String> treeKeys = new ArrayList<String>();
        return keys(root, treeKeys);

    }

    /**
     * Adds the keys in the tree using in order traversal, to our
     * arrayList(treeKeys) which sorts the keys in alphabetical order. It then
     * converts the array list and returns an array of strings with the same order.
     *
     * @param root     - the root Node of the tree.
     * @param treeKeys - An arrayList of the keys in the tree
     * @return an in order array String of all the keys in the tree
     */
    private static String[] keys(Node root, ArrayList<String> treeKeys) {

        if (root == null) {
            return new String[] {};
        }
        keys(root.getLeftChild(), treeKeys);
        if (root.getKey() == "null") {
            treeKeys.add(null);
        } else {
            treeKeys.add(root.getKey());
        }
        keys(root.getRightChild(), treeKeys);

        return listToString(treeKeys);

    }

    /**
     * Converts an arrayList of Strings to an Array of strings of equal length.
     *
     * @param arList - an arrayList of String.
     *
     * @return String[] sArray - an array of Strings with all the String that are in
     *         aList.
     */
    private static String[] listToString(ArrayList<String> arList) {
        String[] strArray = new String[arList.size()];
        for (int i = 0; i < arList.size(); i++) {
            strArray[i] = arList.get(i);
        }
        return strArray;
    }

    /**
     * The following function compares two Strings(newKey and keyInTree) and returns
     * the following:
     *
     * -1 if keyInTree is alphabetically before newKey.
     *
     * 0 if newKey is equal to keyInTree.
     *
     * 1 if keyInTree is alphabetically after newKey.
     *
     *
     * @param compareKey - A string that is the key being compared to keyInTree.
     *
     * @param keyInTree  - A String in the tree.
     *
     * @return an integer representing if newKey is alphabetically before, after or
     *         the same String as keyInTree.
     */
    private static int compareString(String compareKey, String keyInTree) {
        if (compareKey == "null" && keyInTree == "null") {
            return 0;
        }
        if ((compareKey == "null" && keyInTree != null) || compareKey.compareTo(keyInTree) < 0) {
            return -1;
        }
        if (compareKey.compareTo(keyInTree) > 0) {
            return 1;
        } else {
            return 0;
        }

    }

}