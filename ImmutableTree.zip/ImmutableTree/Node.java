/**
 * NAME: LEILI KOUKLANFAR
 *
 * COURSE: COMP 2631
 *
 * INSTRUCTOR: JASON HEARD
 *
 * ASSIGNMENT: #3
 *
 * Creates a Node class which holds all the information required for a tree
 * node.
 *
 * @author leilikouklanfar
 *
 */

public class Node {
    private final String key;
    private final int size;
    private final Node left;
    private final Node right;

    /**
     * Creates a Node with the given detail.
     *
     * @param key   - a String that hold the value of the Nodes key
     * @param left  - a Node that is the left subtree of Node
     * @param right - a Node that is the right subtree of Node
     */
    Node(String key, Node left, Node right) {
        this.key = key;
        this.left = left;
        this.right = right;

        if (left == null && right == null) {
            this.size = 1;
        } else if (left == null && right != null) {
            this.size = right.getSize() + 1;
        } else if (left != null && right == null) {
            this.size = left.getSize() + 1;
        } else {
            this.size = left.getSize() + right.getSize() + 1;
        }
    }

    public int getSize() {
        return size;
    }

    public String getKey() {
        return key;
    }

    public Node getLeftChild() {
        return left;
    }

    public Node getRightChild() {
        return right;
    }

    /**
     * Changes the left subtree of Node by creating a new Node with the same key and
     * right subtree but setting the left subtree of the new node to newLeft.
     *
     * @param newLeft - the new left subtree Node
     * @return - a new Node with a new left subtree
     */
    public Node changeLeft(Node newLeft) {
        return new Node(this.key, newLeft, this.right);
    }

    /**
     * Changes the right subtree of Node by creating a new Node with the same key
     * and left subtree but setting the right subtree of the new node to newRight.
     *
     * @param newRight - the new right subtree Node
     * @return - a new Node with a new right subtree
     */
    public Node changeRight(Node newRight) {
        return new Node(this.key, this.left, newRight);
    }

}
